%%%%%%%%%%%%%%%%%%%%PERFORMS THE MINIMUM DISTANCE ESTIMATION%%%%%%%%%%%%%%%%%%%%

%function [params,Fval]=MinDis(M_vectorized)
% THIS IS THE MAIN PROGRAM THAT PERFORMS THE MINIMUM DISTANCE ESTIMATION OF
% % TRANSITORY INCOME SHOCKS.
% IT CALLES TWO FUNCTIONS NAMED loadMatrixM THAT NEEDS TO RESIDES IN THE SAME DIRECTORY AS
% THE CURRENT PROGRAM.
%INPUTS:MATRIX M CONTAINING EMPIRICAL MOMENTS

M_vectorized = loadMatrixM;

global M_vectorized

% start with some initial guess X0
X0=[0,0,0,0,0];

options=optimset('tolFun',0.001, 'Maxiter',2000);

[params,Fval]=fminunc(@myfun,X0,options);

%%x=fminunc(myfun,X0)

save RESULTS_ALL;

%%end


