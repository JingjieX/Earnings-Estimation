clear all;close all;clc;

M_vectorized = loadMatrixM;

global M_vectorized

% Start with some initial guess X0
X0=[0,0,0,0,0];

% params has positive values
lb=[,0,0,0];
% The probelmhas no upper bounds
ub=[];

% The problem has no linear constraints , so set those arguments to []
A=[];
b=[];
Aeq=[];
beq=[];

% Use fmincon since it's a constrained problem now
params=fmincon(@myfun,X0,A,b,Aeq,beq,lb,ub);

% Display in the order of rho, var_alpha, var_epsilon, var_v
disp(params)

save RESULTS_ALL;

